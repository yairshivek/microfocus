using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ChineseWhispers
{
    class Program
    {

        static void Main(string[] args)
        {
            if (args.Length != 3)
            {
                throw new ArgumentException("Error, invalid argument count \n usage: ChineseWhispers <FileName> <DirectoryPath> <newDirectoryName>");
            }
            string fileName = args[0];
            string directoryPath = args[1];
            string newDirectoryName = args[2];
            string fullFileName = directoryPath + @"\" + fileName;
            string fullsubDirectoryFileName = directoryPath + @"\" + newDirectoryName + @"\" + fileName;

            if (PrintFileInfo(fullFileName))
            {
                CopyFileIntoNewDirectory(fileName, directoryPath, newDirectoryName);
                ReadFile(fullsubDirectoryFileName);
                MemoryStream ms = WriteBinaryDataToMemoryStream(fullsubDirectoryFileName);

                fullsubDirectoryFileName = Path.ChangeExtension(fullsubDirectoryFileName, "gzip");
                CompressDataAndSaveToFile(ms, fullsubDirectoryFileName);

                ms = DeCompressDataIntoMemoryStream(fullsubDirectoryFileName);

                fullFileName = Path.ChangeExtension(fullFileName, "txt");
                ReadBinaryDataFromMemoryStream(ms, fullFileName);
                //ReadFile(fullFileName);
            }
            Console.ReadLine();
        }

        static bool PrintFileInfo(string fullFileName)
        {
            return true;
        }


        static void CopyFileIntoNewDirectory(string fileName, string directoryPath, string newDirectoryName)
        {

        }

        static void ReadFile(string fullFileName)
        {

        }

        static MemoryStream WriteBinaryDataToMemoryStream(string fullFileName)
        {
            return null;
        }


        static void CompressDataAndSaveToFile(MemoryStream ms, string fullFileName)
        {

        }

        static MemoryStream DeCompressDataIntoMemoryStream(string fullFileName)
        {
            return null;
        }

        static void ReadBinaryDataFromMemoryStream(MemoryStream ms, string fullFileName)
        {

        }
    }
}
