using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Compression;

namespace ChineseWhispers {
    class Program {

        static void Main(string[] args) {
            if (args.Length != 3) {
                throw new ArgumentException("Error, invalid argument count \n usage: ChineseWhispers <FileName> <DirectoryPath> <newDirectoryName>");
            }
            string fileName = args[0];
            string directoryPath = args[1];
            string newDirectoryName = args[2];
            string fullFileName = Path.Combine(directoryPath, fileName);
            string fullsubDirectoryFileName = Path.Combine(directoryPath, Path.Combine(newDirectoryName, fileName));

            if (PrintFileInfo(fullFileName)) {
                CopyFileIntoNewDirectory(fileName, directoryPath, newDirectoryName);
                ReadFile(fullsubDirectoryFileName);
                MemoryStream ms = WriteBinaryDataToMemoryStream(fullsubDirectoryFileName);

                fullsubDirectoryFileName = Path.ChangeExtension(fullsubDirectoryFileName, "gzip");
                CompressDataAndSaveToFile(ms, fullsubDirectoryFileName);

                ms = DeCompressDataIntoMemoryStream(fullsubDirectoryFileName);

                fullFileName = Path.ChangeExtension(fullFileName, "txt");
                ReadBinaryDataFromMemoryStream(ms, fullFileName);
                ReadFile(fullFileName);
            }
            Console.ReadLine();
        }

        static bool PrintFileInfo(string fullFileName) {
            FileInfo datFile = new FileInfo(fullFileName);
            if (datFile.Exists) {
                Console.WriteLine("***************************");
                Console.WriteLine("Filename: {0}", datFile.Name);
                Console.WriteLine("Path: {0}", datFile.FullName);
                Console.WriteLine("Length: {0} bytes",
                  datFile.Length.ToString());
                Console.WriteLine("IsReadOnly: {0}",
                  datFile.IsReadOnly.ToString());
                Console.WriteLine("***************************");
            } else {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Cannot find file {0}", fullFileName);
            }
            return datFile.Exists;
        }


        static void CopyFileIntoNewDirectory(string fileName, string directoryPath, string newDirectoryName) {
            DirectoryInfo di = Directory.CreateDirectory(
                Path.Combine(directoryPath, newDirectoryName));
            FileInfo fileToCopy = new FileInfo(
                Path.Combine(directoryPath, fileName));

            try {
                fileToCopy.CopyTo(Path.Combine(di.FullName, fileName));
            } catch (Exception exn) {
                Console.WriteLine("***************************");
                Console.WriteLine(exn.Message);
            }
            PrintFileInfo(Path.Combine(di.FullName, fileName));
        }

        static void ReadFile(string fullFileName) {
            using (FileStream fs = File.Open(fullFileName, FileMode.Open, FileAccess.Read)) {
                using (StreamReader sr = new StreamReader(fs)) {

                    Console.WriteLine("***************************");
                    Console.Write(sr.ReadToEnd());
                    Console.WriteLine();
                    Console.WriteLine("***************************");
                }
            }
        }

        static MemoryStream WriteBinaryDataToMemoryStream(string fullFileName) {
            using (FileStream fs = File.Open(fullFileName, FileMode.Open, FileAccess.Read)) {
                using (StreamReader sr = new StreamReader(fs)) {
                    MemoryStream ms = new MemoryStream();
                    BinaryWriter bw = new BinaryWriter(ms);
                    while (sr.Peek() >= 0) {
                        string row = sr.ReadLine();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(row);
                        string[] columns = row.Split(new char[] { ',' });
                        bw.Write(columns[0]);
                        bw.Write(columns[1]);
                        bw.Write(Convert.ToInt64(columns[2]));
                        bw.Write(Convert.ToInt64(columns[3]));
                        bw.Write(columns[4]);
                        bw.Write(columns[5]);
                    }
                    bw.Flush();
                    Console.ForegroundColor = ConsoleColor.White;
                    return ms;
                }
            }
        }


        static void CompressDataAndSaveToFile(MemoryStream ms, string fullFileName) {
            using (FileStream compressedData = File.Create(fullFileName)) {
                //create compressionStream
                using (GZipStream compressionStream = new GZipStream(compressedData, CompressionMode.Compress)) {
                    ms.Position = 0;
                    //read data from source and feed it to the compressionStream
                    int b = ms.ReadByte();
                    while (b != -1) {
                        compressionStream.WriteByte((byte)b);
                        b = ms.ReadByte();
                    }
                }
            }
        }

        static MemoryStream DeCompressDataIntoMemoryStream(string fullFileName) {
            using (FileStream dataToBeDeCompressed = File.OpenRead(fullFileName)) {
                //create compressionStream
                using (GZipStream compressionStream = new GZipStream(dataToBeDeCompressed, CompressionMode.Decompress)) {
                    MemoryStream ms = new MemoryStream();
                    //read data from source and feed it to the compressionStream
                    int b = compressionStream.ReadByte();
                    while (b != -1) {
                        ms.WriteByte((byte)b);
                        b = compressionStream.ReadByte();
                    }
                    return ms;
                }
            }
        }

        static void ReadBinaryDataFromMemoryStream(MemoryStream ms, string fullFileName) {
            using (FileStream fs = File.Open(fullFileName, FileMode.Create, FileAccess.Write)) {
                using (BinaryReader br = new BinaryReader(ms)) {
                    using (StreamWriter sw = new StreamWriter(fs)) {
                        ms.Position = 0;
                        while (ms.Position < ms.Length) {
                            StringBuilder row = new StringBuilder();
                            row.Append(br.ReadString());
                            row.Append(",");
                            row.Append(br.ReadString());
                            row.Append(",");
                            row.Append(br.ReadInt64().ToString());
                            row.Append(",");
                            row.Append(br.ReadInt64().ToString());
                            row.Append(",");
                            row.Append(br.ReadString());
                            row.Append(",");
                            row.Append(br.ReadString());
                            sw.WriteLine(row.ToString());
                        }
                    }
                }
            }
        }
    }
}

