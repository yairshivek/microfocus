﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace LINQLab {
  class PubsToXml {
    public static void WriteXml() {
      PubsDataContext dc = new PubsDataContext();
      var publishersByCountry = from publisher in dc.publishers
                                group publisher by publisher.country;

      XNamespace pub = "http://pubs.com";
      XElement xml = new XElement(pub + "publishers",
          new XAttribute(XNamespace.Xmlns + "pub", pub),
          from countryGroup in publishersByCountry
          select
          new XElement(pub + "publisher",
              new XAttribute("country", countryGroup.Key),
              from rec in countryGroup
              select
              new XElement(pub + "names",
                  new XElement(pub + "name",
                      new XAttribute("city", rec.city.EndsWith("chen") ? "London" : rec.city),
                      rec.pub_name
                  )
              )
          )
      );

      Console.WriteLine(xml);
      File.WriteAllText("Pubs.xml", xml.ToString());

    }
  }
}

//foreach (var countryGroup in publishersByCountry) {
//  Console.WriteLine(countryGroup.Key);
//  foreach (var publisherRecord in countryGroup) {
//    Console.WriteLine("...{0} : {1}", publisherRecord.pub_name, publisherRecord.city);
//  }
//}