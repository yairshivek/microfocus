﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace LINQLab {
  class Program {
    static void Main(string[] args) {
      // Write Xml File
            Console.ForegroundColor = ConsoleColor.Green;
            PubsToXml.WriteXml();

      // Read names elements in Xml
            Console.ForegroundColor = ConsoleColor.Cyan;
            XElement pubs = XElement.Load("Pubs.xml");
            XNamespace pub = "http://pubs.com";
            var names = from name in pubs.Descendants(pub + "name")
                        select name;
            foreach (var n in names)
                Console.WriteLine(n);

      // Read Northwind
            Console.ForegroundColor = ConsoleColor.Blue;
            NorthwindDataContext dc = new NorthwindDataContext();
            var q = from c in dc.Customers
                    select c;
            foreach (var c in q)
              Console.Write(c.CustomerID + ", ");
            Console.WriteLine();

      // Join the Xml and the SQL
            Console.ForegroundColor = ConsoleColor.Yellow;
            var cityJoin = from p in pubs.Descendants(pub + "name")
                    join c in dc.Customers
                    on (string)p.Attribute("city") equals c.City
                    select new { Name = (string)p.Value, City = c.City, c.CustomerID };
            foreach (var rec in cityJoin)
              Console.WriteLine(rec);
        }
  }
}
