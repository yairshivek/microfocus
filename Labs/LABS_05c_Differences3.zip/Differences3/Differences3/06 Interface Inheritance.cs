﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_06InterfaceOperationClashes {
    class Test {
        public static void Main() { 
        }
    }

    public interface ITaxable {
        void GetRegularTax();
    }
    public interface ISuperTaxable : ITaxable {
        void GetSuperTax();
    }

    public class Person /* : ISuperTaxable */ { // TODO 1 : remove comments, right-click > Implement Interface
                                                // Note Person has the ITaxable methods as well as the ISuperTaxable ones
    }
}
