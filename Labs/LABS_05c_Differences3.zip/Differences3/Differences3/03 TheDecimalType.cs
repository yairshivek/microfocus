﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_03TheDecimalType {
    class Test {
        public static void Main() {     // TODO 1 - set as the startup object
            double fortyTwo = 42.0;
            //decimal d = fortyTwo; // TODO 2 - uncomment for compiler error, fix by a cast. Check with Debug

            //TakesADecimalParameter(42.0);  // TODO 3 - uncomment, compile, fix by an 'M' suffix on 42.0
        }

        public static void TakesADecimalParameter(decimal d) {
        }
    }
}
