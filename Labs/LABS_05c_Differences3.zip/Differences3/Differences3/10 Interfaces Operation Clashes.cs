﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_10InterfaceOperationClashes {
    class Test {
        public static void Main() { // TODO 1 - set as the startup object
            Person p = new Person();
            //p.PlayFootball();   // TODO 3 : uncomment set a breakpoint, single-step through the 'Default' method
            ((IAmericanResident)p).PlayFootball();  // TODO 4: uncomment. step throuhg, Note the syntax
        }
    }

    public interface IEnglishResident {
        void PlayFootball();
    }
    public interface IAmericanResident {
        void PlayFootball();
    }
    // TODO 2 : uncomment, right-click and implement the 1st interface as normal and the 2nd explicitly
    //          delete the exception throwing code
    public class Person /* : IEnglishResident, IAmericanResident */  {
    }
}
