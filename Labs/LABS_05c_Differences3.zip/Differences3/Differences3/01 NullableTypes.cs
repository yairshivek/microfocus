﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_01NullableTypes {
    class Test {
        public static void Main() { // TODO 1 set as Startup object, set a breakpoint at the start
                                    // F5 and single-step through
            int? i = null;          // hovering over 'i' to see its values
            i = 42;
            if (i != null) {
                int j = i.Value;
            }
            if (i.HasValue) {
                int j = i.Value;
            }
        }
    }
}
