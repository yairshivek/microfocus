﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_05Interfaces {
    class Test {
        public static void Main() { 
            //ISpy spy1 = new Spy();    // TODO 3 : uncomment these
            //spy1.WithMyLittleEye();   // note you can access interface methods via class or interface
            //Spy spy2 = new Spy();
            //spy2.WithMyLittleEye();
        }
    }

    public interface ISpy {
        void WithMyLittleEye(); // TODO 1 : note interface methods use the visibility of the interface
    }

    public class Spy /* : ISpy */ { // TODO 2 : remove /* */ comments
                                // right-click ISpy > Implement Interface > Implement Interface
    }
}

