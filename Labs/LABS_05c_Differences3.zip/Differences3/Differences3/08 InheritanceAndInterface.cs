﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_08InheritanceAndInterface {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            DerivedClass dc = new DerivedClass();
            // TODO 3, 5 and 5
        }
    }
    public interface ITax {
        void Pay();
    }
    class BaseClass {                   // <== This Line (see below)
        public int Data { get; set; }
    }
    // Note the inheritance syntax
    class DerivedClass : BaseClass {    // TODO 2 see below
    }
}


// TODO 2
// modify the arrowed line above marked 'This Line" to read :
// public class DerivedClass : BaseClass, ITax
// right-click the ITax on this line and select Implement Interface > Implement Interface  (don't choose the Explicit)

// TODO 3 - call the method
// type dc. - note the intellisense shows the Pay method

// TODO 4 - Explicit interfaces
// remove the procedure
//public void Pay() {
//    throw new NotImplementedException();
//}
// and this time right-click ITax and select Implement Interface > Implement Interface Explicitly
// repeat TODO 3 again - note the interface is hidden

// TODO 5
// type ((ITax)dc). - if you know about the interface, you can call it

