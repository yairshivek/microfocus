﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace CS_04SwitchStatement {
    class Test {
        public static void Main() {  // TODO 1 set as Startup object
            int iMonth = 2;
            int days;
            switch (iMonth) {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8: days = 31;
                    break;          // TODO 2 : Note the break statements

                case 4:
                case 6: days = 30;
                    break;

                default: days = 28;
                    break;      // TODO 3 : even required here
            }

            // TODO 4: Can also do with strings (or enums)
            switch ("May") {
                case "January":
                case "March":
                case "May":
                case "July":
                case "August": days = 31;
                    break;

                case "April":
                case "June": days = 30;
                    break;

                default: days = 28;
                    break;
            }

        }
    }
}
