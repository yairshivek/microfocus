﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_09Polymorphism {

    class Test {
        public static void Main() { // TODO 1 set as Startup object
            BaseClass bc = new DerivedClass();
            bc.Method();
        }
    }

    class BaseClass {
        public void Method() {
        }
    }
    class DerivedClass : BaseClass {
        //public void Method() {    // TODO 1 - uncomment and see warning
                                    
        //}
    }
}

// TODO 2
//   - delete the method in the subclass
//   - add 'virtual' to the method in the base class
//   - in the sub-class, type 'override' <space> and implement the method
//   - using debug confirm it steps into the derived method
//   - remove the 'virtual' and 'override' and see which method is called
//   - do a Solution > Clean and note the warning
//   - add the keyword 'new' to the method in DerivedClass, do a Solution > Clean and note no warning. See which method is called
//  Keep your results, we'll discuss later.

// TODO 3
//  Remove the new keyword
//  Add in another class inheriting from DerivedClass, implement the override & note that you do not put 'virtual' and 'override'
//  in the middle class
