﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_07PropertiesInAnInterface {
    class Test {
        public static void Main() { 
        }
    }

    public interface Island {
        string Capital {get;set;}
    }
    public class UK /*: Island */ { // TODO 1 : uncomment and implement interface
                                    // note you can effectively now have data in an interface
    }
}
