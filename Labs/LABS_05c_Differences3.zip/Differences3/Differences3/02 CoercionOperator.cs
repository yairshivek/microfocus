﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_02CoercionOperator {
    class Test {
        public static void Main() { // TODO 1 set as Startup object, F5 and single-step through
            Operation(null);
            Operation(new SomeClass());

        }
        private static void Operation(SomeClass sc) {
            if (sc == null) {                   // TODO 2 : run and note ToString() outputs
                sc = new SomeClass();
            }

            //sc = sc ?? new SomeClass();         // TODO 2 : comment out the above 3 lines of code, uncomment this line and run     
            Console.WriteLine(sc.ToString());
        }
    }
    class SomeClass {
    }
}
