﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PoorMansFileSystemWatcher {
    class Program {
        static void Main(string[] args) {
            FileSystemWatcher fsw = new FileSystemWatcher();
            // TODO - 5 need to subscribe to the event here
            //fsw.FileFound += new FileFoundEventHandler(fsw_FileFound);
            fsw.FileFound += (o, e) => Console.WriteLine("file found = {0}", e.Filename);
            fsw.EnableRaisingEvents = true; // this sets the file watcher going
            for (int i = 0; i < 20; i++) {
                Console.Write(".");
                Thread.Sleep(1000);
            }
        }

         // TODO - 6 need an event handler
       //static void fsw_FileFound(object sender, FileFoundEventArgs e) {
       //     Console.WriteLine("file found = {0}", e.Filename);
       // }
    }

    // ########  This code would be in a library #########

    class FileSystemWatcher {
        // TODO -3 declare an event using your delegate
        public event FileFoundEventHandler FileFound;

        private bool enableRaisingEvents;
        public bool EnableRaisingEvents {
            get { return enableRaisingEvents; }
            set {
                enableRaisingEvents = value;
                if (enableRaisingEvents) {
                    Task.Factory.StartNew(() => {
                        Thread.Sleep(10000);
                        // TODO - 4 raise the event when a new file is recognized
                        OnFileFound("Eureka.txt");
                    });
                }
            }
        }
        protected void OnFileFound(string filename) {
            if (FileFound != null) {
                FileFound.Invoke(this, new FileFoundEventArgs(filename));
            }
        }
    }
    // TODO - 2 define a delegate for the event
    public delegate void FileFoundEventHandler(object sender, FileFoundEventArgs e);

    // TODO - 1 define a FileFoundEventArgs class
    public class FileFoundEventArgs : EventArgs {
        public string Filename { get; set; }
        public FileFoundEventArgs(string filename) {
            this.Filename = filename;
        }
    }
}
