﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PoliceDispatcher {
    public partial class CrimeFighter : UserControl {
        public CrimeFighter() {
            InitializeComponent();
        }
        
        public bool OnACase { get; private set; }

        // Says whether the checkbox is currently selected
        public bool OnDuty {
            get { return chkOnDuty.Checked; }
        }

        // A field to keep track of the CrimeReportedEventArgs object that a CrimeFighter is
        // currently 'handling(chasing)'
        private CrimeReportedEventArgs activeCrimeReport;
        
        // Dynamically connect and disconnect to the CrimeReported event
        // depending on whether this CrimeFighter is on duty or not
        private void OnDutyStatusChanged(object sender, System.EventArgs e) {
            if (OnDuty)
            {
                lblStatus.Text = "Patrolling the streets";
                PoliceDispatcherForm.Instance.CrimeReported += OnCrimeReported;
            }
            else
            {
                lblStatus.Text = "";
                PoliceDispatcherForm.Instance.CrimeReported -= OnCrimeReported;
            }
            OnACase = false;
        }

        // A method (with correct signature) to respond to the CrimeReported event
        private void OnCrimeReported(object sender, CrimeReportedEventArgs e) {
            if ( !OnACase && e.CrimeFighterOnCase == null)
            {
                e.CrimeFighterOnCase = this;
                activeCrimeReport = e;  // must "save" 'e' in an instance variable before it goes out of scope  
                lblStatus.Text = "Responding to " + e.Crime + " at " + e.Location;
                OnACase = true;
                ChaseVillains();
            }
        }
        // Implement a ChaseVillains method to chase down the villains
        private void ChaseVillains() {
            // Make a tick happen within 5 seconds
            Random r = new Random(Environment.TickCount);
            timerChase.Interval = r.Next(1000, 5000);
            timerChase.Enabled = true;
        }

        // TODO Declare a 'VillainCaptured' event
        public event CrimeReportedEventHandler VillainCaptured;

        // a Tick has happened, this method handles that event
        private void OnTimerTicked(object sender, System.EventArgs e) {
            timerChase.Enabled = false;
            OnACase = false;
            lblStatus.Text = "Patrolling the streets";
            // standard pattern - private method calls the protected overridable to raise event 
            OnVillainCaptured(activeCrimeReport);
        }

        // does the actual raising of the villain Captured event
        protected virtual void OnVillainCaptured(CrimeReportedEventArgs e) {
            // did anyone register an interest
            if (VillainCaptured != null)
            {
                VillainCaptured(this, e);
            }
        }       
    }
}
