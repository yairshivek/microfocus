﻿namespace PoliceDispatcher {
    partial class CrimeFightersForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.cfDynamicDuo = new PoliceDispatcher.CrimeFighter();
            this.cfPCPlod = new PoliceDispatcher.CrimeFighter();
            this.cfClouseau = new PoliceDispatcher.CrimeFighter();
            this.cfSpiderMan = new PoliceDispatcher.CrimeFighter();
            this.SuspendLayout();
            // 
            // cfDynamicDuo
            // 
            this.cfDynamicDuo.DisplayColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cfDynamicDuo.DisplayName = "Dynamic Duo";
            this.cfDynamicDuo.Location = new System.Drawing.Point(2, 1);
            this.cfDynamicDuo.Name = "cfDynamicDuo";
            this.cfDynamicDuo.Size = new System.Drawing.Size(483, 104);
            this.cfDynamicDuo.TabIndex = 0;
            // 
            // cfPCPlod
            // 
            this.cfPCPlod.DisplayColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.cfPCPlod.DisplayName = "PC Plod";
            this.cfPCPlod.Location = new System.Drawing.Point(2, 333);
            this.cfPCPlod.Name = "cfPCPlod";
            this.cfPCPlod.Size = new System.Drawing.Size(483, 114);
            this.cfPCPlod.TabIndex = 3;
            // 
            // cfClouseau
            // 
            this.cfClouseau.DisplayColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.cfClouseau.DisplayName = "Inspector Clouseau";
            this.cfClouseau.Location = new System.Drawing.Point(2, 221);
            this.cfClouseau.Name = "cfClouseau";
            this.cfClouseau.Size = new System.Drawing.Size(483, 114);
            this.cfClouseau.TabIndex = 2;
            // 
            // cfSpiderMan
            // 
            this.cfSpiderMan.DisplayColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.cfSpiderMan.DisplayName = "SpiderMan";
            this.cfSpiderMan.Location = new System.Drawing.Point(2, 108);
            this.cfSpiderMan.Name = "cfSpiderMan";
            this.cfSpiderMan.Size = new System.Drawing.Size(483, 114);
            this.cfSpiderMan.TabIndex = 1;
            // 
            // CrimeFightersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 445);
            this.ControlBox = false;
            this.Controls.Add(this.cfDynamicDuo);
            this.Controls.Add(this.cfPCPlod);
            this.Controls.Add(this.cfClouseau);
            this.Controls.Add(this.cfSpiderMan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CrimeFightersForm";
            this.ShowInTaskbar = false;
            this.Text = "Crime Fighters";
            this.ResumeLayout(false);

        }

        #endregion

        private CrimeFighter cfDynamicDuo;
        private CrimeFighter cfSpiderMan;
        private CrimeFighter cfClouseau;
        private CrimeFighter cfPCPlod;
    }
}