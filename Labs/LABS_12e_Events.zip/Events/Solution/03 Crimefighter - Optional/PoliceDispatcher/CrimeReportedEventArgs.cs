using System;

namespace PoliceDispatcher {

    public class CrimeReportedEventArgs {

        public readonly string Crime;
        public readonly string Location;

        public CrimeFighter CrimeFighterOnCase { get; set; }
        public UnsolvedReason Reason { get; set; }

        public CrimeReportedEventArgs(string crime, string location) {
            Crime = crime;
            Location = location;
        }

    }

    // Define the delegate type/signature for the CrimeReported event
    public delegate void CrimeReportedEventHandler(object sender, CrimeReportedEventArgs e);

    public enum UnsolvedReason {
        AllOffDuty,
        AllBusy
    }
}
