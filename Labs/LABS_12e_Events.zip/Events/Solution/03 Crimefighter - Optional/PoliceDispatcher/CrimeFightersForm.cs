﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PoliceDispatcher {
    public partial class CrimeFightersForm : Form {
        private bool allowToClose = false;
        public CrimeFightersForm() {
            InitializeComponent();
        }
        public void CloseForm() {
            allowToClose = true;
            Close();
        }

        private void CrimeFightersForm_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
            e.Cancel = !allowToClose;
        }
    }
}
