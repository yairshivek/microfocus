using System;

namespace PoliceDispatcher {

    public class CrimeReportedEventArgs : EventArgs { 
        // needs to inherit from EventArgs to satisfy 
        // a constraint on TEventArgs in type EventHandler<TEventArgs>

        public readonly string Crime;
        public readonly string Location;

        public CrimeFighter CrimeFighterOnCase { get; set; }
        public UnsolvedReason Reason { get; set; }

        public CrimeReportedEventArgs(string crime, string location) {
            Crime = crime;
            Location = location;
        }

    }

    // Define the delegate type/signature for the CrimeReported event
    // delegate type not needed as we will use EventHandler<T>
    //public delegate void CrimeReportedEventHandler(object sender, CrimeReportedEventArgs e);

    public enum UnsolvedReason {
        AllOffDuty,
        AllBusy
    }
}
