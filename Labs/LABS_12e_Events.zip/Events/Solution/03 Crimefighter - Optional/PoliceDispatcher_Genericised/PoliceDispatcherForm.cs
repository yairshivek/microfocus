﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PoliceDispatcher {
    public partial class PoliceDispatcherForm : Form {

        #region Stuff you needn't worry about
        private CrimeFightersForm cf;
        private static PoliceDispatcherForm theInstance;
        public static PoliceDispatcherForm Instance {
            get {
                if (theInstance == null)
                {
                    theInstance = new PoliceDispatcherForm();
                }
                return theInstance;
            }
        }
        
        public PoliceDispatcherForm() {
            InitializeComponent();
        }
        private void PoliceDispatcherForm_Load(object sender, EventArgs e) {
            cf = new CrimeFightersForm();
            cf.Owner = this;
            cf.Show();
            cf.DesktopLocation = new Point(this.Right + 5, this.Top);
        }
        private void PoliceDispatcherForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (cf != null && !cf.IsDisposed)
            {
                cf.CloseForm();
            }
        }
        #endregion

        // TODO use List<T> to keep track of unsolved crimes
        private List<CrimeReportedEventArgs> unsolvedCrimeReports = new List<CrimeReportedEventArgs>();

        // TODO Declare a CrimeReported event
        //public event CrimeReportedEventHandler CrimeReported;
        public EventHandler<CrimeReportedEventArgs> CrimeReported;

        private void OnAlertClicked(object sender, System.EventArgs e) {
            // Respond to the Alert buttons' Click event and raise CrimeReportedEvent
            // but standard pattern is to raise it in overridable method after building an XXXEventArgs object to send
            CrimeReportedEventArgs evt = new CrimeReportedEventArgs(txtCrime.Text, txtLocation.Text);
            OnCrimeReported(evt);
        }

        // TODO: Implement the OnCrimeReported method to actually raise the event
        // The code below is after dealing with the 'unsolved' crimes (optional enhancement)
        // In the early part of the practical it should start with
        // 'if (CrimeReported != null) ... then raise the event
        protected virtual void OnCrimeReported(CrimeReportedEventArgs e) {
            if (CrimeReported != null)  // at least 1 CrimeFighter registered
            {
                CrimeReported(this, e);    // do broadcast to 1 or more on duty Crimefighters

                if (e.CrimeFighterOnCase != null)         // Is anybody dealing with it?
                {
                    e.CrimeFighterOnCase.VillainCaptured += OnCrimeSolved;
                }
                else
                {
                    e.Reason = UnsolvedReason.AllBusy;
                    unsolvedCrimeReports.Add(e);
                }

            }
            else   // no-one registered?
            {
                e.Reason = UnsolvedReason.AllOffDuty;
                 unsolvedCrimeReports.Add(e);
            }
           
        }

        // Updates list box with 1 unsolved crime
        private void OnCrimeSolved(object sender, CrimeReportedEventArgs e) {
            string s = string.Format("{0} at {1} solved by {2}", e.Crime, e.Location, e.CrimeFighterOnCase.DisplayName);
            lstSolvedCrimes.Items.Add(s);
            e.CrimeFighterOnCase.VillainCaptured -= OnCrimeSolved;
        }
        
        // Handler for click of 'Report Unsolved' button
        private void ReportUnsolvedCrimesClicked(object sender, EventArgs e) {
            foreach (CrimeReportedEventArgs crea in unsolvedCrimeReports)
            {
                ProcessUnsolvedCrime(crea);
            }
            unsolvedCrimeReports.Clear();     // empty the list

        }

        // Updates list box with 1 unsolved crime
        private void ProcessUnsolvedCrime(CrimeReportedEventArgs e) {
            string s = string.Format("{0} at {1} unsolved. {2}", e.Crime, e.Location, e.Reason);
            lstSolvedCrimes.Items.Add(s);
        }

        // Utility method to enable students to easily empty the list box by double clicking it
        private void lstSolvedCrimes_DoubleClick(object sender, EventArgs e) {
            lstSolvedCrimes.Items.Clear();
        }
    }
}
