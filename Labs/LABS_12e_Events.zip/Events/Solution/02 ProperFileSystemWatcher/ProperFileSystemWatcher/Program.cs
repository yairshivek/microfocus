﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ProperFileSystemWatcher {
    class Program {
        static void Main(string[] args) {
            FileSystemWatcher fsw = new FileSystemWatcher(@"c:\tmp");
            fsw.Created += (o, e) => Console.WriteLine(e.Name);
            fsw.EnableRaisingEvents = true;
            Console.ReadLine();
        }
    }
}
