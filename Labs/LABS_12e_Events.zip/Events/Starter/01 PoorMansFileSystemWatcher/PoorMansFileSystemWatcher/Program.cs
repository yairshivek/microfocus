﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PoorMansFileSystemWatcher {
    class Program {
        static void Main(string[] args) {
            FileSystemWatcher fsw = new FileSystemWatcher();
            // TODO - 5 need to subscribe to the event here
            fsw.EnableRaisingEvents = true; // this sets the file watcher going
            for (int i = 0; i < 20; i++) {
                Console.Write(".");
                Thread.Sleep(1000);
            }
        }
        // TODO - 6 need an event handler
    }

    // ########  This code would be in a library #########

    class FileSystemWatcher {
        // TODO declare an event using your delegate
        private bool enableRaisingEvents;
        public bool EnableRaisingEvents {
            get { return enableRaisingEvents; }
            set {
                enableRaisingEvents = value;
                if (enableRaisingEvents) {
                    Task.Factory.StartNew(() => {
                        Thread.Sleep(10000);
                        // TODO - 4 raise the event when a new file is recognized
                        string filename = "Eureka.txt";
                        Console.WriteLine("File found {0}", filename);
                    });
                }
            }
        }
    }
    // TODO - 2 define a delegate for the event
    // TODO - 1 define a FileFoundEventArgs class
}
