﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PoliceDispatcher {
    public partial class PoliceDispatcherForm : Form {

        #region Stuff you needn't worry about
        private CrimeFightersForm cf;
        private static PoliceDispatcherForm theInstance;
        public static PoliceDispatcherForm Instance {
            get {
                if (theInstance == null)
                {
                    theInstance = new PoliceDispatcherForm();
                }
                return theInstance;
            }
        }
        
        public PoliceDispatcherForm() {
            InitializeComponent();
        }
        private void PoliceDispatcherForm_Load(object sender, EventArgs e) {
            cf = new CrimeFightersForm();
            cf.Owner = this;
            cf.Show();
            cf.DesktopLocation = new Point(this.Right + 5, this.Top);
        }
        private void PoliceDispatcherForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (cf != null && !cf.IsDisposed)
            {
                cf.CloseForm();
            }
        }
        #endregion

        // TODO use List<T> to keep track of unsolved crimes
       

        // TODO Declare a CrimeReported event
        

        private void OnAlertClicked(object sender, System.EventArgs e) {
            // Respond to the Alert buttons' Click event and initiate the process of raising the CrimeReportedEvent
            // but standard pattern is to raise it in overridable method after building an XXXEventArgs object to send

            
        }

        // TODO: Implement the OnCrimeReported method to actually raise the event
        // In the early part of the practical it should start with
        // 'if (CrimeReported != null) ... then raise the event
        // later it will get more complex
        protected virtual void OnCrimeReported(CrimeReportedEventArgs e) {
            

        }

        
              
        
        
        // Updates list box with 1 solved crime
        private void OnCrimeSolved(object sender, CrimeReportedEventArgs e) {
            //string s = string.Format("{0} at {1} solved by {2}", e.Crime, e.Location, e.CrimeFighterOnCase.DisplayName);
            //lstSolvedCrimes.Items.Add(s);

        }

        // Handler for click of 'Report Unsolved' button - still to be connected to event
        private void ReportUnsolvedCrimesClicked(object sender, System.EventArgs e) {
            // Iterate thru the unsolvedCrimes list passing each in turn to the ProcessUnsolvedCrime method
            

        }
        

        // Updates list box with 1 unsolved crime
        private void ProcessUnsolvedCrime(CrimeReportedEventArgs e) {
            //string s = string.Format("{0} at {1} unsolved. Reason:- {2}", e.Crime, e.Location, "DummyReason");
            //lstSolvedCrimes.Items.Add(s);
        }

        // Utility method to enable students to easily empty the list box during testing by double clicking it 
        private void lstSolvedCrimes_DoubleClick(object sender, EventArgs e) {
            lstSolvedCrimes.Items.Clear();
        }
    }
}
