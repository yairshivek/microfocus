﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PoliceDispatcher {
    public partial class CrimeFighter : UserControl {
        public CrimeFighter() {
            InitializeComponent();
        }
        
        public bool OnACase { get; private set; }

        // Says whether the checkbox is currently selected
        public bool OnDuty {
            get { return chkOnDuty.Checked; }
        }

        // Dynamically connect and disconnect to the CrimeReported event
        // depending on whether this CrimeFighter is on duty or not
        private void OnDutyStatusChanged(object sender, EventArgs e) {
            if (OnDuty)
            {
                lblStatus.Text = "Patrolling the streets";
                
            }
            else
            {
                lblStatus.Text = "";
                
            }
            OnACase = false;
        }

        // TODO Define a field to keep track of the CrimeReportedEventArgs object that a CrimeFighter is
        // currently 'handling(chasing)'
        

        // A method (with correct signature) to respond to the CrimeReported event
        private void OnCrimeReported(object sender, CrimeReportedEventArgs e) {
            if ( !OnACase )
            {
                lblStatus.Text = "Responding to " + e.Crime + " at " + e.Location;
                OnACase = true;
            }
        }


        // A ChaseVillains method to chase down the villains
        private void ChaseVillains() {
            //// Make a tick happen within 5 seconds
            //Random r = new Random(Environment.TickCount);
            //timerChase.Interval = r.Next(1000, 5000);
            //timerChase.Enabled = true;
        }

       

        // TODO Declare a 'VillainCaptured' event - a simple one liner, 
        // an event is a field whose type is always a delegate type!
        

        // This is the method that will ultimately raise the VillainCaptured event (if anyone registered for it)
        // This method will be invoked by you when the Villain is captured (when the timer ticks!!)  
        protected virtual void OnVillainCaptured(CrimeReportedEventArgs e) {
            

        }

        private void OnTimer_Tick(object sender, EventArgs e) {
            //timerChase.Enabled = false;
            //OnACase = false;
            //lblStatus.Text = "Patrolling the streets";
        }

       
        
       

      
              
    }
}
