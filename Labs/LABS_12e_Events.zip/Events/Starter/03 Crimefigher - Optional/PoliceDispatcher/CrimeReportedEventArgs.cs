using System;

namespace PoliceDispatcher {
    public class CrimeReportedEventArgs   {

        public readonly string Crime;
        public readonly string Location;

        public CrimeReportedEventArgs(string crime, string location) {
            //Crime = crime;
            //Location = location;
        }
    }

    // TODO Define the delegate type/signature for the CrimeReportedEventHandler type
    // This will later become the data type of both your CrimeReported & VillainCaptured events.
    
    //public delegate void XxxEventHandler(??? ???, ???EventArgs e);           // a clue!!
    
}
