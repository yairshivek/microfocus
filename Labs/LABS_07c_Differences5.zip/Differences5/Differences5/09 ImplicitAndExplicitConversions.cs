﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_09ImplicitAndExplicitConversions { // TODO 1 set as Startup object
    class Test {
        public static void Main() {
            Metre m = new Metre() { Length = 3 };
            //Foot f = (Foot)m;     // TODO 2 : uncomment this - it doesn't compile
            //Foot f2 = m;        // TODO 4 : Uncomment this and change explicit to implicit below. Run and check the result
        }
    }

    class Metre {
        public double Length { get; set; }
    }
    class Foot {
        public double Length { get; set; }

        // TODO 3 : uncomment this - now we can cast Meters to Feet. Run and check the result
        //public static explicit operator Foot(Metre m) {
        //    return new Foot() { Length = m.Length / 3.2808399 };
        //}
    }
}
