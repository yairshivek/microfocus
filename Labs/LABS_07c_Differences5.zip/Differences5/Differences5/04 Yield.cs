﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace CS_04Yield {
    class Test {
        static void Main(string[] args) {  // TODO 1 - set as the startup object
            Collection collection = new Collection();

            // TODO 2 - look at the basic pattern
            // The basic pattern
            IEnumerator enumerator = collection.GetEnumerator();
            while (enumerator.MoveNext()) {
                Console.WriteLine(enumerator.Current);
            }

            // The Foreach Pattern
            foreach (string str in collection) {
                Console.WriteLine(str);
            }

            // TODO 3 - see how yield can allow you to write neat C# that gets transformed to 
            // the Enumerator pattern in the IL
            // Using the yield keyword
            DataAccess da = new DataAccess();
            foreach (string str in da.Collection()) {
                Console.WriteLine(str);
            }
        }
    }

    // Here's the clunky way of doing it
    // You would need to write all of this yourself
    public class Collection : IEnumerable {
        string[] strings = new string[] { "A", "B", "C", "D" };
        public IEnumerator GetEnumerator() {
            return new MyEnumerator(strings);
        }
    }

    public class MyEnumerator : IEnumerator {
        string[] strings;
        public MyEnumerator(string[] strings) {
            this.strings = strings;
        }
        private int index = -1;
        public void Reset() { index = -1; }
        public object Current { get { return strings[index]; } }
        public bool MoveNext() { return ++index < strings.Length; }
    }


    // 'yield' does it much neater
    public class DataAccess {
        public IEnumerable<string> Collection() {
            string[] strings = new string[] { "A", "B", "C", "D" };
            foreach (string str in strings) {
                yield return str;
            }
            // TODO 3 - uncomment these
            //yield return "test data - 1";
            //yield return "test data - 2";
            //yield return "test data - 3";
        }
    }

}
