﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Note : this is just a way of demonstrating the dynamic keyword
// It is only to be used where the compiler cannot be aware of a method/field but you know it will be present at runtime

namespace CS_07DynamicType {
    class Test01 {
        public static void Main() { // TODO 1 set as Startup object
            Base derived = new Derived();
            //derived.Data = "Wont compile";    // TODO 2 - uncomment this & confirm it does not compile. Replace comment

            //dynamic d = derived; // TODO 3 - uncomment this & confirm it compiles & runs correctly
            //d.Data = "Will now";    
            //string str = d.Data;
        }
    }
    class Base {
    }
    class Derived : Base {
        public string Data { get; set; }
    }
}
