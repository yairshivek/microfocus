﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace CS_03Dispose {
    class Dispose {
        static void Main(string[] args) {  // TODO 1 set as Startup object
            Font f = new Font("Arial", 10.0f);
            // exception can happen
            f.Dispose();
        }
    }
}

// TODO 2 - refactor the above into a try/finally block & call Dispose in the 'finally'
//          note - you will need to set f to null to get it to compile
// TODO 3 - then refactor into a 'using' block

