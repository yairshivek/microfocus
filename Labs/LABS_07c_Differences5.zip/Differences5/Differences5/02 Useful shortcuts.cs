﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// TODO : 1 Add a library
//          right-click the Solution
//          Add > New Project > Class Library, leave the default name
//          Delete the starter class file Class1.cs
//          right-click ClassLibrary1 > Add > Class. Name it MyClass


namespace CS_02UsefulShortcuts {

    class Test {
        public static void Main() {
            // TODO 2 : type in the following line exactly as shown but without the // coment. You will get a red underline
            // MyClass mc = new MyClass();
            // TODO 3 : select either 'MyClass' with the mouse - you will see a blue underbar
            //          it will ask you if you want it to generate a class for you. Click away to abanodn this

            // TODO 4a: There are 3 reasons why this does not compile
            //          1)  Difference5 needs to reference ClassLibrary1
            //          2) MyClass needs to be a public class
            //          3) We need the namespace 'ClassLibrary1' in scope

            // TODO 4b: right-click Differences5>References > Add Reference, select Projects tab, choose ClassLibrary1
            // TODO 4c : add 'public' to the definition of MyClass
            // TODO 4d : back in Differences5.Main, select 'MyClass' (blue underbar) then press control+dot
            //          Now you get the 'using' statement. Select the top one.



            // TODO 5: type in this line exactly as shown but without the // comment
            //mc.MyMethod(42);
            //          right-click MyMethod > Generate > Method Stub.
            //          Confirm a method stub has been placed in MyClass
            
        }

    }
}
