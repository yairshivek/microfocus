﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_06PartialClasses {
    class PartialClasses {
        public static void Main() {  // TODO 1 - set as the startup object
            SomeClass sc = new SomeClass();
            // TODO 3 - type sc. and see I, J, K on the intellisense
            // it's as if all the partial classes have been rolled into 1 class

            // This is extremely useful for auto-generated classes when you need to add some code
            // that must not be lost on a re-generate
        }
    }
    partial class SomeClass {   // TODO 2 - note the same class name and the keyword partial
        public int I { get; set; }
    }
    partial class SomeClass {
        public int J { get; set; }
    }
    partial class SomeClass {
        public int K { get; set; }
    }
}
