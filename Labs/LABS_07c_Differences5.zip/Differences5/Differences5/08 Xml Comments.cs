﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_08XmlComments {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            Method("aa", 42);       // TODO 3 - hover the mouse over the method name to see your summary text
        }

        // TODO 2 - type in three forwared slashes (///) immediately above the following method
        // then enter some text between the summary tags

        public static void Method(string param1, int param2) {
        }

        // Note - to build the help file see
        // http://shfb.codeplex.com/
    }
}
