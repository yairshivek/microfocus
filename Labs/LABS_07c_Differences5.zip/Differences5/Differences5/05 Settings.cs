﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_05Settings {
    class Test {
        public static void Main() { // TODO 1 set as Startup object, run & see output = "Chopin"
            Dog rover = new Dog() { FavouriteComposer = "Chopin"  }; // TODO 2a: we really want "Chopin" to be a config setting
                    // TODO 2b : project > right-click > Add > New Item > Settings File
                    //          Change 'Name' in the settings file to 'FavouriteComposer'
                    //          Change Scope to Application
                    //          In the value field put Bach
                    //          Replace FavouriteComposer = "Chopin"
                    //          with FavouriteComposer = Differences5.Settings1.Default.FavouriteComposer
                    //          note that its typesafe

                    // TODO 3 : double-click App.Config - you will see it in there
                    // TODO 4 : right-click Differences5 project > Open Folder in Windows Explorer
                    //          drill down to the Debug folder
                    //          double-click Differences5.exe
                    //          open Differences5.exe.config with Notepad (looks familiar? it should do - its your App.Config)
                    //          Change Bach to your favourite composer & run the exe again
            
            Console.WriteLine("Dog's favourite composer : {0}", rover.FavouriteComposer);
            Console.ReadLine();
        }
    }
    class Dog {
        public string FavouriteComposer {get;set;}
    }
}
