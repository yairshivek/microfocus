﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using CS_01HelperMethods.OtherNamespace;  // TODO 5b

namespace CS_01HelperMethods {
    // Note: this is not so much a feature of the language, but using a feature of the language
    // to solve the problem of "I'm sure I had a helper method for that somewhere"

    class Test {
        public static void Main() { // TODO 1 set as Startup object
            SomeClass sc = new SomeClass();
            // TODO 2 : type sc. and confirm the intellisense shows InstanceMethod()

            // TODO 3 : add breakpoint & step through Method1 & check sc.Data afterwards
            OtherNamespace.HelperClass.MyHelperMethod1(sc, "data1");    

            // TODO 4: pipe the output of Method2 into ToLower, add a breakpoint after the return to confirm it has piped through
            SomeClass scOut = OtherNamespace.HelperClass.ToLower(OtherNamespace.HelperClass.MyHelperMethod2(sc, "DaTa2"));

            // TODO 5a: I think that
            //          a) Piplining is quite handy (its functional style programming)
            //          b) The syntax to get it is clumsy
            //          c) That what you really want to do is as per the line below
            //              sc <dot> <intellisense select Method1> <dot> <intellisense select ToLower> <dot>
            //
            //  do the TODOs 5b (at top of file) to 5e
            //  then type in this line (type it in rather than copy so you see the intellisense)
            //    SomeClass scOut2 = sc.MyHelperMethod2("DaTa2").ToLower();
            //  Add a breakpoint after it to confirm that it all worked.

            // TODO 6 : comment out the using CS_01HelperMethods.OtherNamespace; - note it doesn't compile
            //          and there is no clue that you're missing a namespace

            // TODO 7: Moral : use this technique for you helper methods but place them in a namespace
            //                  that is always included in every class.
        }
    }

    public class SomeClass {
        public string Data1 { get; set; }
        public string Data2 { get; set; }
        public void InstanceMethod() {
        }
    }

    namespace OtherNamespace {
        public class HelperClass {         // TODO 5c : make this a public static class
            public static void MyHelperMethod1(SomeClass sc, string setData1) {
                sc.Data1 = setData1;
            }
            // Here's a form that can be used in a pipeline where Methods can be piped together
            public static SomeClass MyHelperMethod2(SomeClass sc, string setData2) {    // TODO 5d : change MyHelperMethod2(SomeClass to MyHelperMethod2( this SomeClass
                SomeClass scOut = new SomeClass() { Data1 = sc.Data1 };
                scOut.Data2 = setData2;
                return scOut;
            }
            public static SomeClass ToLower(SomeClass sc) {    // TODO 5e : insert the 'this' keyword here too
                SomeClass scOut = new SomeClass() { Data1 = sc.Data1.ToLower(), Data2 = sc.Data2.ToLower() };
                return scOut;
            }
        }
    }
}
