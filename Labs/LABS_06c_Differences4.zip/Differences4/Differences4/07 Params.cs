﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace CS_07Params {
    class Test {
        public static void Main() { // TODO 1 set as Startup object, F5, sum = 55
            int sum = Sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
            Debugger.Break();
        }
        static int Sum(params int[] ints) {
            int sum = 0;
            for (int i = 0; i < ints.Length; i++)
                sum += ints[i];
            return sum;
        }
    }
}
