﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_03ObjectInitializers {
    class Test {
        public static void Main() {
            SomeClass sc = new SomeClass("abc")  ;    // TODO 1 :
                                      //       ^^ in here type {Property1 = "x", Property2 = "y"}
        }
    }

    class SomeClass {
        private string essentialData;
        public SomeClass(string essentialData) {
            this.essentialData = essentialData;
        }

        public string Property1 { get; set; }
        public string Property2 { get; set; }
        public string Property3 { get; set; }
    }
}
