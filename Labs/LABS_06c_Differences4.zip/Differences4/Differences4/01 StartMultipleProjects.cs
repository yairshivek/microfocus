﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_01StartMultipleProjects {
    class Test {

        // TODO
        // 1) Set this as the startup Main

        // 2) Right-click solution (NB not the project - the 'Solution')
        //      Add > New Project > C# Console App. Take the default name

        // 3) enter this code
        //static void Main(string[] args) {
        //    Console.WriteLine("ConsoleApp1 running");
        //    Console.ReadLine();
        //}

        // 4) Right-click Solution > Set Startup Projects
        //  Select Multiple Startup Project and set them both to start
        //  F5 - see both projects running

        // 5) Right-click project SomewhatDifferent > Set as Startup Project
        //  F5  leave it running

        // 6) Right-click ConsoleApplication1 > Debug > Start new instance
        //  The 2nd project now also runs

        public static void Main() {
            Console.WriteLine("SomewhatDifferent running");
            Console.ReadLine();
        }
    }
}
