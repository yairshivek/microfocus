﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_04RefAndOut {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            int i = 42;
            Method1(i);
            int result1 = i;    // TODO 2 - run to here in debug - result1 is as you would expect

            //Method2(i); // TODO 3 - uncomment, compile, modify to (ref i), and run - result2 is as you would expect
            //int result2 = i; 

            Method3(out i); // TODO 4 - uncomment, compile, modify to (out i) - result 3 is 99
            int result3 = i;
        }

        public static void Method1(int i) {
            i += 1;
        }
        public static void Method2(ref int i) {
            i += 1;
        }
        public static void Method3(out int i) {
            i = 99;     // TODO 5 - comment out, compile. Leave commented out
            //i += 1;   // TODO 6 - uncomment, compile. leave with this commented out and above line re-instated.
        }
    }

}
