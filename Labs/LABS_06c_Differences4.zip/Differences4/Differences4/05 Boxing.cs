﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_05Boxing {
    class Test {
        public static void Main() { // TODO 1 set as Startup object then run with debug. Check j is 99
            int i = 42;
            int j = (int)MethodThatTakesAReferenceType(i); // box and unbox
            //long k = (long)MethodThatTakesAReferenceType(i); // TODO 2 - uncomment and run
        }
        public static object MethodThatTakesAReferenceType(object o) {
            int k = (int)o; // unbox
            k = 99;
            return k;   // box again
        }
    }
}
