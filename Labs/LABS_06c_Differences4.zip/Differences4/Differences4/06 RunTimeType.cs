﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_06RunTimeType {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            BaseClass bc = new DerivedClass();

            if (bc is DerivedClass) {   // TODO 2 - the 'is' operator. Step into with Debug
                DerivedClass dc1 = (DerivedClass)bc;
                //...
            }

            DerivedClass dc2 = bc as DerivedClass; // TODO 3 - the 'as' operator. Step into with Debug
            if (dc2 != null) {
                // ...
            }
        }
    }
    class BaseClass {
    }
    class DerivedClass : BaseClass {
    }
}
