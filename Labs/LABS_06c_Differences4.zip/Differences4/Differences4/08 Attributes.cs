﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_08Attributes {

    class Test {
        [STAThread]     // called Annotations in Java
        public static void Main() {
            // The full name is STAThreadAttribute, but the compiler allows the 'Attribute' to be omitted
            STAThreadAttribute x;
        }
    }
}
