﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_02Constructors {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            BaseClass bc = new DerivedClass();
        }
    }
    class BaseClass {
        public BaseClass(string str) {
        }
    }
    class DerivedClass : BaseClass {
        // TODO 2 - type in ctor tab tab & note the parameterless constructor is added
        public DerivedClass() : this("default") {

        }
        public DerivedClass(string str) : base(str) {
        }
    }
}

// TODO 3 modify the default constructor in DerivedClass to be
// public DerivedClass() : this("default") {  // ie a chained constructor
// Uncomment the code in Main() and step through with debug
