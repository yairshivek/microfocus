﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_09Indexer {

    class Test {

        public static void Main() { // TODO 1 set as Startup object
            FootballClub manU = new FootballClub();
            Player p = manU.Players[1]; // TODO 1 : run & confirm this is Best
                                        // TODO 2a : comment out the above line
            //Player p2 = manU[1];  // TODO 3b : uncomment, run & check p2 is still Best
        }
    }

    class FootballClub {
        public List<Player> Players = new List<Player>() {  //TODO 2b : make into a private List
            new Player { Name="Charlton" },
            new Player { Name = "Best"},
            new Player { Name = "Law"}
        };

        //public Player this[int index] {   // TODO 3a : uncomment the indexer
        //    get {
        //        return Players[index];
        //    }
        //}
    }
    class Player {
        public string Name { get; set; }
    }
}
