﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericMethod {
    class Program {
        static void Main(string[] args) {

            string[] strArray = CreateStringArray(42, "init");  // TODO 5 : change to CreateArray<string>(42, "init");  Run & check
            int[] iArray = CreateIntArray(42, -1); // TODO 6 : change to CreateArray(42, -1); and note how the compiler infers the <int>  Run & check

        }   // TODO 1 : set a breakpoint here and confirm we have string and int arrays.

        // TODO 4 : Comment out these 2 non-generic methods
        static string[] CreateStringArray(int elements, string initialValue) {
            string[] array = new string[elements];
            for (int ix = 0; ix < elements; ix++) {  // TODO 2 : Question - why not use a foreach here? 
                array[ix] = initialValue;
            }
            foreach (string str in array) {
                //str = initialValue; // TODO 2 : uncomment this line to see why. Comment it out again afterwards
            }
            return array;
        }
        static int[] CreateIntArray(int elements, int initialValue) {
            int[] array = new int[elements];
            for (int ix = 0; ix < elements; ix++) {
                array[ix] = initialValue;
            }
            return array;
        }

        // TODO 3 : uncomment the generic method
        //static T[] CreateArray<T>(int elements, T initialValue) {
        //    T[] array = new T[elements];
        //    for (int ix = 0; ix < elements; ix++) {
        //        array[ix] = initialValue;
        //    }
        //    return array;
        //}
    }
}

