﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LostProperty {
    public enum Category {
        suitcase,
        umbrella
    }
    public class Shelf {
        public string Location { get; set; }
    }
    class Program {
        static void Main(string[] args) {
            Dictionary<Category, List<Shelf>> lostProperty = new Dictionary<Category, List<Shelf>>();
            lostProperty.Add(Category.suitcase, new List<Shelf>());
            lostProperty.Add(Category.umbrella, new List<Shelf>());
            lostProperty[Category.suitcase].Add(new Shelf() { Location = "A" });
            lostProperty[Category.suitcase].Add(new Shelf() { Location = "B" });
            lostProperty[Category.suitcase].Add(new Shelf() { Location = "C" });
            lostProperty[Category.umbrella].Add(new Shelf() { Location = "D" });

            foreach (KeyValuePair<Category, List<Shelf>> kvp in lostProperty) {
                foreach (Shelf s in kvp.Value) {
                    Console.WriteLine("{0} is on shelf {1}", kvp.Key.ToString(), s.Location );
                }
            }
        }
    }
}
