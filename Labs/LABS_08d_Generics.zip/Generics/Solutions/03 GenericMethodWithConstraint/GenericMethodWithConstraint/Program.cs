﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericMethodWithConstraint {
    class Item : IComparable<Item> {
        public string SortOrder { get; set; }

        public int CompareTo(Item other) {
            return string.Compare(this.SortOrder, other.SortOrder);
        }
    }
    class Program {
        static void Main(string[] args) {
            List<Item> items = new List<Item>() {
                new Item(){ SortOrder = "a"},
                new Item(){ SortOrder = "b"},
                new Item(){ SortOrder = "c"},
                new Item(){ SortOrder = "d"},
            };
            List<Item> result = Where(items, new Item() { SortOrder = "b" });
            foreach (Item item in result) {
                Console.WriteLine(item.SortOrder);
            }
        }

        static List<T> Where<T>(List<T> input, T threshold) where T : IComparable<T>  {
            List<T> output = new List<T>();
            foreach (T item in input) {
                if (item.CompareTo(threshold) >= 0) {
                    output.Add(item);
                }
            }
            return output;
        }
    }
}
