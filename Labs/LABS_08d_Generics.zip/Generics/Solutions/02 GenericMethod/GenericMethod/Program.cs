﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericMethod {
    class Program {
        static void Main(string[] args) {

            string[] strArray = CreateArray<string>(42, "init");  // TODO 5 : change to CreateArray<string>(42, "init");  Run & check
            int[] iArray = CreateArray(42, -1); // TODO 6 : change to CreateArray(42, -1); and note how the compiler infers the <int>  Run & check
        }  

        // TODO 3 : uncomment the generic method
        static T[] CreateArray<T>(int elements, T initialValue) {
            T[] array = new T[elements];
            for (int ix = 0; ix < elements; ix++) {
                array[ix] = initialValue;
            }
            return array;
        }
    }
}

