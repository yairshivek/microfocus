﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_05VerbatimStrings {
    class Test {
        string path = @"c:\Program Files\AAA\BBB";  // Everything is a literal until the next double-quote
        string canHaveANewline = @"line1
line2
line3";
    }
}
