﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_02ConstAndReadOnly {
    class Test {
        const string constString = "abc";
        readonly string readOnlyString = "def";

        public Test() {
            //readOnlyString = "x";               // TODO 1, remove comment : readonly settable in the constructor
            //constString = "cannot set a const"; // TODO 2, remove comment : const is not settable anywhere
        }
        public void Method() {
            // readOnlyString = "x";       // TODO 3, remove both comments
            // constString = "x";           // neither can be set in a regular method
        }
    }
}
