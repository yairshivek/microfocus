﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_06Enums {
    class Test {
        public static void Main() { // TODO 1 set as Startup object & run without debug
            MutuallyExclusive me = MutuallyExclusive.Stop;
            Console.WriteLine(me.ToString());

            MutuallyInclusive mi = MutuallyInclusive.LeatherSeats | MutuallyInclusive.ElectricWindows;
            Console.WriteLine(mi.ToString());

            MutuallyExclusive mi2 = (MutuallyExclusive)Enum.Parse(typeof(MutuallyExclusive), "Stop");
            // TODO 3 - run with debug & confirm mi2 is assigned to "Stop"
        }
    }
    enum MutuallyExclusive {
        Stop,
        Go
    }

    //[Flags]                   // TODO 2 - uncomment the Flags attribute and run again
    enum MutuallyInclusive {
        CDPlayer=1,
        LeatherSeats=2,
        ElectricWindows=4,
        TurboCharger=8
    }
}
