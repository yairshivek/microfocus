﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Note : With all these labs, ensure you leave each file compilable.
// The instructions are in // TODO markers - follow these through in sequence

namespace CS_01PropertyProcedures {
    class Test {
        public static void Main() { // TODO 1 in the Project Properties set CS_01PropertyProcedures as Startup object
            PropertyProcedures p = new PropertyProcedures();
            // p.Name += "def";    // TODO 3 - uncomment, add a breakpoint and single-step through
                                // check Name is "abcdef" at the end
                                // note the very neat syntax at the client

            // p.Age = 42;         // TODO 5 - check this works

            //int i = p.X;        // TODO 7 - uncomment this, run & figure out why there's a problem
        }
    }
    class PropertyProcedures {
        private string name = "abc"; // TODO 2 - right-click > Refactor > Encapsulate Field (to produce a full property)

        // TODO 6 - on Name, type in 'private' before 'set' - cannot write to the property from outside the class. Remove the 'private'

        // public int Age { get; set; }    // TODO 4 uncomment this auto-property style

        private int x;
        public int X {
            get { return X; }
            set { X = value; }
        }
    }
}
