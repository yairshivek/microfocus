﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_07Parse {
    class Test {
        public static void Main() { // TODO 1 set as Startup object & run without debug
            int i = int.Parse("42");
            //int j = int.Parse("42X"); // TODO 2 - Comment out then try. replace comment after running

            int k;
            if (int.TryParse("42X", out k)) {  // TODO 3 - try with good and bad values of the string
                // k is set
            }
        }
    }
}
