﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_03OverrideToString {
    class Test {
        public static void Main() { // TODO 1 - Set Main in project Properties
            OverrideToString ots = new OverrideToString();
            Console.WriteLine(ots); // TODO 2 - Run and note output : ToString() is the 'default' operation
        }

    }
    class OverrideToString {
        string Name = "Fred Flintstone";
        int age = 42;

        // TODO 3 - enter 'override' spacebar then select ToString()
        //          enter this 1 line of code & run again
        // return string.Format("Name={0}, Age={1}", Name, age);

    }
}
// Note you should ALWAYS override ToString for your classes
