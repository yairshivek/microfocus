﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CS_05ValueAndReferenceTypes {
    class Test {
        public static void Main() { // TODO 1 set as Startup object
            ReferenceType rt1 = new ReferenceType() { Value = "original" };
            ReferenceType rt2 = rt1;
            rt1.Value = "changed";
            string rt2Value = rt2.Value; 
            // TODO 2 - hover the mouse over 'ReferenceType' above and note that it's a class
            //        - look at the value of rt2Value

            ValueType vt1 = new ValueType() { Value = "original" }; // note the 'new' for a value type
            ValueType vt2 = vt1;
            vt1.Value = "changed";
            string vt2Value = vt2.Value;
            // TODO 2 - hover the mouse over 'ValueType' above to see its a struct
            //        - look at the value of vt2Value

            // TODO 4 - try it with a DateTime object

            // TODO 5 - try it with a string object
        }
    }
    class ReferenceType {   // NB a class
        public string Value { get; set; }
    }
    struct ValueType {      // NB a struct
        public string Value { get; set; }
    }
}
// If you're familiar with C++, structs are similar to classes with copy constructors
