﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace CS_04StringBuilder {
    class Test {

        public static void Main() { // TODO 1 - Set Main in project Properties
            int limit = 100000;
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            string str1 = "";
            for (int i = 0; i < limit; i++) {
                str1 += "a";
            }
            sw1.Stop();

            Stopwatch sw2 = new Stopwatch();
            sw2.Start();
            StringBuilder sb = new StringBuilder(1000);
            for (int i = 0; i < limit; i++) {
                sb.Append("a"); // TODO 2 - note usage of StringBuilder
            }
            sw2.Stop();

            // TODO 3 - run and note the speed advantage of using StringBuilder
            Console.WriteLine("concatenating strings {0}", sw1.ElapsedMilliseconds);
            Console.WriteLine("using StringBuilder {0}", sw2.ElapsedMilliseconds);
        }
    }
}
