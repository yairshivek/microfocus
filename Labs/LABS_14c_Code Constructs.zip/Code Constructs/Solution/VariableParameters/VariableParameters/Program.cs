﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace VariableParameters {
    class Program {
        static void Main(string[] args) {
            List<double> times = new List<double>();
            for (int k = 0; k < 20; k++) {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                Stopwatch sw = new Stopwatch();
                sw.Start();

                for (int i = 0; i < 10000000; i++) {
                   // Variableparams(new object[] { 42, 77.0 });
                    Fixedparams(42, 77.0);
                }
                sw.Stop();
                times.Add(sw.Elapsed.TotalMilliseconds);
                Console.WriteLine(sw.Elapsed.TotalMilliseconds + "msec");
            }
            Console.WriteLine("Average = " + times.Average());
        }

        private static int Variableparams(params object[] filterCriteria) {
            int p1 = 0;
            double p2 = 0.0;
            if (filterCriteria.Length >= 1) {
                p1 = (int)filterCriteria[0];
            }
            if (filterCriteria.Length >= 2) {
                p2 = (double)filterCriteria[1];
            }
            return p1;
        }
        private static int Fixedparams(int p1) {
            return p1;
        }
        private static int Fixedparams(int p1, double p2) {
            return p1;
        }
    }
}
