﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Exceptions {
    class Program {
        static void Main(string[] args) {
            List<double> times = new List<double>();
            for (int k = 0; k < 20; k++) {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                Stopwatch sw = new Stopwatch();
                sw.Start();
                int j = 42;
                object o = j;
                for (int i = 0; i < 10000; i++) {
                    //CatchAnException(0);    
                    NotExceptional(0);
                }
                sw.Stop();
                times.Add(sw.Elapsed.TotalMilliseconds);
                Console.WriteLine(sw.Elapsed.TotalMilliseconds + "msec");
            }
            Console.WriteLine("Average = " + times.Average());
        }

        private static void CatchAnException(int i) {
            int j = 42;
            try {
                j /= i;
            } catch (Exception ex) {
            }
        }
        private static int NotExceptional(int i) {
            int j = 42;
            if (i == 0) {
                return 0;
            }
            j /= i;
            return j;
        }
    }
}
