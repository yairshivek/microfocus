﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SealedEtc {
    class Program {
        static void Main(string[] args) {
            List<double> times = new List<double>();
            for (int k = 0; k < 20; k++) {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                Stopwatch sw = new Stopwatch();
                MyClass x = new MySubClass(); // MySubClass
                sw.Start();
                for (int i = 0; i < 10000000; i++) {
                    int j = x.SimpleMethod(i);
                }
                sw.Stop();
                times.Add(sw.Elapsed.TotalMilliseconds);
                Console.WriteLine(sw.Elapsed.TotalMilliseconds + "msec");
            }
            Console.WriteLine("Average = " + times.Average());
        }
    }
    class MyClass {
        public virtual int SimpleMethod(int i) {
            return ++i;
        }
    }
    class MySubClass : MyClass {
        public override sealed int SimpleMethod(int i) {
            return ++i;
        }
    }
}
