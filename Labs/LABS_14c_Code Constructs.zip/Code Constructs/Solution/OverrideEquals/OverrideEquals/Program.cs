﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace OverrideEquals {
    class Program {
        public static bool bSame;
        static void Main(string[] args) {
            List<double> times = new List<double>();
            for (int k = 0; k < 20; k++) {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

                Rectangle r1 = new Rectangle() { Length = 20, Breadth = 30 };
                Rectangle r2 = new Rectangle() { Length = 20, Breadth = 30 };
                Stopwatch sw = new Stopwatch();
                sw.Start();
                for (int i = 0; i < 1000000; i++) {
                    bSame = r1.Equals(r2);
                }
                sw.Stop();
                times.Add(sw.Elapsed.TotalMilliseconds);
                Console.WriteLine(sw.Elapsed.TotalMilliseconds + "msec");
            }
            Console.WriteLine("Average = " + times.Average());
        }

    }
    public struct Rectangle {
        public int Length { get; set; }
        public int Breadth { get; set; }
        //public string Colour { get; set; }

        public override bool Equals(object ob) {
            if (ob is Rectangle)
                return Equals((Rectangle)ob);
            else
                return false;
        }
        public override int GetHashCode() {
            return base.GetHashCode();
        }
        private bool Equals(Rectangle rect) {
            return this.Length == rect.Length && this.Breadth == rect.Breadth;
        }
    }

    // Afterwards you could try using these if you like
    //bSame = r1 == r2;

    //public static bool operator ==(Rectangle r1, Rectangle r2) {
    //    return r1.Equals(r2);
    //}
    //public static bool operator !=(Rectangle r1, Rectangle r2) {
    //    return !r1.Equals(r2); ;
    //}
}
