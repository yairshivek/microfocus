﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Boxed {
    class Program {
        static void Main(string[] args) {
            List<double> times = new List<double>();
            for (int k = 0; k < 20; k++) {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                Stopwatch sw = new Stopwatch();
                sw.Start();
                int j = 42;
                object o = j;
                for (int i = 0; i < 10000000; i++) {
                   NonBoxed(i);
                   //Boxed(i);  // Boxed on every iteration
                   //Boxed(o);  // Boxed just once
                }
                sw.Stop();
                times.Add(sw.Elapsed.TotalMilliseconds);
                Console.WriteLine(sw.Elapsed.TotalMilliseconds + "msec");
            }
            Console.WriteLine("Average = " + times.Average());
        }

        private static int Boxed(object o) {
            int i = (int)o;
            return ++i;
        }
        private static int NonBoxed(int i) {
            return ++i;
        }
    }
}
