﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DelegatesAndLambdas {
    public class Customer {
        public int CustId { get; set; }
        public string Name { get; set; }
        //public List<Order> Orders = new List<Order>();
        public override string ToString() {
            return CustId + ", " + Name;
        }
    }
    public class Order {
        public int CustId { get; set; }
        public string Name { get; set; }
    }


    class Program {
        static void Main(string[] args) {
            List<Customer> customers = new List<Customer>() {
                new Customer(){CustId=1, Name="Sherlock Holmes"},
                new Customer(){CustId=3, Name="Tony Hancock"},
            };

            List<Order> orders = new List<Order>() {
                new Order(){ CustId = 1, Name = "SH Order1"},
                new Order(){ CustId = 3, Name = "TH Order1"},
                new Order(){ CustId = 3, Name = "TH Order2"},
            };

            //customers[0].Orders.Add(new Order() { Name = "SH Order1" });
            //customers[1].Orders.Add(new Order() { Name = "TH Order1" });
            //customers[1].Orders.Add(new Order() { Name = "TH Order2" });

            //IEnumerable<Customer> result = from cust in customers
            //                    where cust.Orders.Count>1
            //                    select cust;
            
            //foreach (Customer cust in result) {
            //    Console.WriteLine(cust);
            //}

            Console.WriteLine("===Flat Join==");

            // Flattened Join
            var result = from c in customers
                         join o in orders on c.CustId equals o.CustId
                         select new { c.Name, OrderName = o.Name };
            foreach (var r in result) {
                Console.WriteLine(r);
            }

            Console.WriteLine("===Group Join==");

            // Group Join
            var result2 = from c in customers
                         join o in orders on c.CustId equals o.CustId into _orders
                         where _orders.Count() > 1
                         select new { c.Name, Orders = _orders };
            foreach (var r in result2) {
                Console.WriteLine(r.Name);
                foreach (Order o in r.Orders) {
                    Console.WriteLine("..." + o.Name);
                }
            }

            // Using Let
            var result3 = from c in customers
                          join o in orders on c.CustId equals o.CustId into _orders
                          let count = _orders.Count()
                          where count > 0
                          orderby count descending
                          select new { c.Name, count };
            foreach (var r in result3) {
                Console.WriteLine(r);
            }

        }

    }

}
