﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Drawing;

namespace Predicates {
    class Program {
        static void Main(string[] args) {

            // the ??? are where you fill in the code - intellisense will help you

            Console.WriteLine("===== All beatles with names of 5 chars or longer ===========");
            string[] beatles = new string[] { "John", "George", "Paul", "Ringo" };
            var beatlets = beatles.ToList().FindAll(s => s.Length >= 5);
            foreach (string str in beatlets) {
                Console.WriteLine(str);
            }

            Console.WriteLine("===== All processes using >1Gb of memory, listed in order ===========");
            var results = Process.GetProcesses()
                .ToList()
                .FindAll(p => p.WorkingSet64 > 1024 * 1024)
                .OrderBy(p => p.WorkingSet64);
            foreach(var r in results) {
                Console.WriteLine(r.ProcessName);
            }

            Console.WriteLine("====== The 17 times table up to 200 ==========");
            var results2 = Enumerable.Range(1, 200).ToList().FindAll(i => i % 17 == 0);
            foreach (int i in results2) {
                Console.WriteLine(i);
            }

            Console.WriteLine("======= How random is Random =========");
            Random rand = new Random();
            StringBuilder sb = new StringBuilder(50);
            for (int i = 0; i <= 50; i++) {
                sb.Append(".");
            }

            // have 100 goes at creating a random number between 0 & 1
            // multiply by 50 to get the range 0=>50
            // Convert to integer using the Convert class
            // set the resulting index in sb to 'x'
            Enumerable.Range(0,100)
                .ToList()
                .ForEach(i => {
                    double randDouble = rand.NextDouble();
                    sb[Convert.ToInt16(randDouble * 50)] = 'x'; 
                });
            Console.WriteLine(sb.ToString());
        }
    }
}
