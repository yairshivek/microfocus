﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DelegatesAndLambdas {
    public class Customer {
        public int CustId { get; set; }
        public bool IsRetail {get;set;}
        public string Name { get; set; }
        public string CompanyCode { get; set; }
        public string Department { get; set; }
        public string Address { get; set; }
        public byte[] Picture { get; set; }
        public override string ToString() {
            return CustId + ", " + Name;
        }
    }
    public class RetailCustomer {
        public int CustId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public override string ToString() {
            return CustId + ", " + Name;
        }
    }
    class Program {
        static void Main(string[] args) {
            List<Customer> customers = new List<Customer>() {
                new Customer(){CustId=1, IsRetail=true, Name="Sherlock Holmes", Address="112B Baker Street"},
                new Customer(){CustId=3, IsRetail=true, Name="Tony Hancock", Address="2 Railway Cuttings"},
                new Customer(){CustId=2, IsRetail=false, Name="Sahara Canoe Club", Address="1 The Desert", CompanyCode="SCC", Department="Sales"},
                new Customer(){CustId=4, IsRetail=false, Name="Grabbit & Runn", Address="1 Lawyers Retreat", CompanyCode="GAR", Department="Billing"},
            };

            //List<Order> orders = new List<Order>() {
            //    new Order(){ CustId = 1, Name = "SH Order1"},
            //    new Order(){ CustId = 2, Name = "TH Order1"},
            //    new Order(){ CustId = 2, Name = "TH Order2"},
            //};

            IEnumerable<Customer> result = from cust in customers
                                where cust.IsRetail
                                select cust;
            
            foreach (Customer cust in result) {
                Console.WriteLine(cust);
            }

        }

    }

}
