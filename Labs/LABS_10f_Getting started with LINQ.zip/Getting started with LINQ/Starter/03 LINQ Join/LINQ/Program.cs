﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DelegatesAndLambdas {
    public class Customer {
        public int CustId { get; set; }
        public string Name { get; set; }
        public List<Order> Orders = new List<Order>();
        public override string ToString() {
            return CustId + ", " + Name;
        }
    }
    public class Order {
        //public int CustId { get; set; }
        public string Name { get; set; }
    }


    class Program {
        static void Main(string[] args) {
            List<Customer> customers = new List<Customer>() {
                new Customer(){CustId=1, Name="Sherlock Holmes"},
                new Customer(){CustId=3, Name="Tony Hancock"},
            };

            customers[0].Orders.Add(new Order() { Name = "SH Order1" });
            customers[1].Orders.Add(new Order() { Name = "TH Order1" });
            customers[1].Orders.Add(new Order() { Name = "TH Order2" });

            //List<Order> orders = new List<Order>() {
            //    new Order(){ CustId = 1, Name = "SH Order1"},
            //    new Order(){ CustId = 3, Name = "TH Order1"},
            //    new Order(){ CustId = 3, Name = "TH Order2"},
            //};

        }

    }

}
