﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelegatesAndLambdas {
    public class Item {
        public string ValueForFilter { get; set; }
    }
    class Program {
        static void Main(string[] args) {
            List<Item> items = new List<Item>() {
                new Item(){ ValueForFilter = "able"},
                new Item(){ ValueForFilter = "was"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "ere"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "saw"},
                new Item(){ ValueForFilter = "elba"},
            };

            List<Item> result = Where(items, item => item.ValueForFilter.Contains("e") );
            
            foreach (Item item in result) {
                Console.WriteLine(item.ValueForFilter);
            }

        }

        static List<T> Where<T>(List<T> input, MyDelegate<T> del) {
            List<T> output = new List<T>();
            foreach (T item in input) {
                if (del.Invoke(item)) {
                    output.Add(item);
                }
            }
            return output;
        }


    }
    public delegate bool MyDelegate<T>(T item);
}
