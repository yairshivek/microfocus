﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Drawing;

namespace Predicates {
    class Program {
        static void Main(string[] args) {

            // the ??? are where you fill in the code - intellisense will help you

            Console.WriteLine("===== All beatles with names of 5 chars or longer ===========");
            string[] beatles = new string[] { "John", "George", "Paul", "Ringo" };
            //var beatlets = ???
            //foreach (string str in beatlets) {
            //    Console.WriteLine(str);
            //}

            Console.WriteLine("===== All processes using >1Gb of memory, listed in order ===========");
            //var results = Process.GetProcesses()
            // ???
            //foreach(var r in results) {
            //    Console.WriteLine(r.ProcessName);
            //}

            Console.WriteLine("====== The 17 times table up to 200 ==========");
            //var results2 = Enumerable.Range ???
            //foreach (int i in results2) {
            //    Console.WriteLine(i);
            //}

            Console.WriteLine("======= How random is Random =========");
            Random rand = new Random();
            StringBuilder sb = new StringBuilder(50);
            for (int i = 0; i <= 50; i++) {
                sb.Append(".");
            }
            
            // have 100 goes at creating a random number between 0 & 1
            // multiply by 50 to get the range 0=>50
            // Convert to integer using the Convert class
            // set the resulting index in sb to 'x'

            //Enumerable.Range ???
            Console.WriteLine(sb.ToString());
        }
    }
}
