﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndLambdas {
    public class Item {
        public string ValueForFilter { get; set; }
    }
    class Program {
        static void Main(string[] args) {
            List<Item> items = new List<Item>() {
                new Item(){ ValueForFilter = "able"},
                new Item(){ ValueForFilter = "was"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "ere"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "saw"},
                new Item(){ ValueForFilter = "elba"},
            };

            List<Item> result = Where(items, item => item.ValueForFilter.Contains("e") );
            foreach (Item item in result) {
                Console.WriteLine(item.ValueForFilter);
            }

            List<DateTime> dates = new List<DateTime>() {
                new DateTime(1066,10,14),   // Battle of Hastings, 14th October 1066
                new DateTime(1215,6,15),    // Magna Carta, 15th June 1215
                new DateTime(1918,11,11),   // First World War Armistice, 11th November 1918
                new DateTime(1969,7,20),    // First man on the moon, 20th July 1969
                new DateTime(3000,1,1),     // Next Labour Government
            };
            List<DateTime> historicalDates = Where(dates, d => d < DateTime.Now);
            foreach (DateTime d in historicalDates) {
                Console.WriteLine(d.ToShortDateString());
            }
        }

        //////////////////////////////////////////////////////////////////////////

        static List<T> Where<T>(List<T> input, MyDelegate<T> del) {
            List<T> output = new List<T>();
            foreach (T item in input) {
                if (del.Invoke(item)) {
                    output.Add(item);
                }
            }
            return output;
        }


    }
    public delegate bool MyDelegate<T>(T item);
}
