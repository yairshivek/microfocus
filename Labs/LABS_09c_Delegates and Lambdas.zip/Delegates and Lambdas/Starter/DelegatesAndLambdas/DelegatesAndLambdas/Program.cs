﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelegatesAndLambdas {
    public class Item {
        public string ValueForFilter { get; set; }
    }
    class Program {
        static void Main(string[] args) {
            List<Item> items = new List<Item>() {
                new Item(){ ValueForFilter = "able"},
                new Item(){ ValueForFilter = "was"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "ere"},
                new Item(){ ValueForFilter = "i"},
                new Item(){ ValueForFilter = "saw"},
                new Item(){ ValueForFilter = "elba"},
            };
            List<Item> result = Where(items);
            foreach (Item item in result) {
                Console.WriteLine(item.ValueForFilter);
            }
        }

        static List<Item> Where(List<Item> input) {
            List<Item> output = new List<Item>();
            foreach (Item item in input) {
                if (item.ValueForFilter.Contains("e")) {
                    output.Add(item);
                }
            }
            return output;
        }
    }
}
