﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ
{
  public class Exam
  {
    public string ExamCode { get; set; }
    public string ExamName { get; set; }
    public int Duration { get; set; }
  }
}
