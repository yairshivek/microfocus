﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ
{
  public class Result
  {
    public string ExamCode { get; set; }
    public string Initials { get; set; }
    public int Marks { get; set; }
  }
}
