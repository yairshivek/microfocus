﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ
{
  class Program
  {
    #region "Declaring, creating and filling 3 lists Students(6) / Exams(3) & Results (18) 
    private static List<Student> students = new List<Student>() { 
                     // 6 students, 3 male, 3 female, 4 aged 13, 2 aged 14
                    new Student { Initials = "AA", Name = "Alice Arrum", Age = 13, Gender = "F", Hobby = "Music" },
                    new Student { Initials = "BB", Name = "Bertie Booster", Age = 13, Gender = "M", Hobby = "Sport" },
                    new Student { Initials = "CC", Name = "Clarissa Cave", Age = 13, Gender = "F", Hobby = "Films" },
                    new Student { Initials = "DD", Name = "Denzil Doodge", Age = 13, Gender = "M", Hobby = "Music" },
                    new Student { Initials = "EE", Name = "Eliza Erst", Age = 14, Gender = "F", Hobby = "Sport" },
                    new Student { Initials = "FF", Name = "Fariq Fahwaz", Age = 14, Gender = "M", Hobby = "Sport" }
        };          // end of filling 'students' with 6 * students

    private static List<Exam> exams = new List<Exam>() {
                     // 3 exams with varying durations
                    new Exam { ExamCode = "ENG", ExamName = "English", Duration = 60 },
                    new Exam { ExamCode = "MATH", ExamName = "Maths", Duration = 50 },
                    new Exam { ExamCode = "SCI", ExamName = "Science", Duration = 40 }
        };          // end of filling 'exams' with 3 * exams

    private static List<Result> results = new List<Result>() { 
                   // English results
                    new Result { ExamCode = "ENG", Initials = "AA", Marks = 78 },
                    new Result { ExamCode = "ENG", Initials = "BB", Marks = 72 },
                    new Result { ExamCode = "ENG", Initials = "CC", Marks = 73 },
                    new Result { ExamCode = "ENG", Initials = "DD", Marks = 75 },
                    new Result { ExamCode = "ENG", Initials = "EE", Marks = 74 },
                    new Result { ExamCode = "ENG", Initials = "FF", Marks = 75 },
                    // Math results
                    new Result { ExamCode = "MATH", Initials = "AA", Marks = 82 },
                    new Result { ExamCode = "MATH", Initials = "BB", Marks = 84 },
                    new Result { ExamCode = "MATH", Initials = "CC", Marks = 84 },
                    new Result { ExamCode = "MATH", Initials = "DD", Marks = 81 },
                    new Result { ExamCode = "MATH", Initials = "EE", Marks = 79 },
                    new Result { ExamCode = "MATH", Initials = "FF", Marks = 73 },
                    // Science results
                    new Result { ExamCode = "SCI", Initials = "AA", Marks = 67 },
                    new Result { ExamCode = "SCI", Initials = "BB", Marks = 69 },
                    new Result { ExamCode = "SCI", Initials = "CC", Marks = 63 },
                    new Result { ExamCode = "SCI", Initials = "DD", Marks = 66 },
                    new Result { ExamCode = "SCI", Initials = "EE", Marks = 58 },
                    new Result { ExamCode = "SCI", Initials = "FF", Marks = 67 }
        };   // end of filling 'results' with 18 * exam Results 
    #endregion

    static void Main()
    {
      //Console.WriteLine("***********");
      //ExamScores();
      //Console.WriteLine("***********");
      //ExamScoresPlusNameLookup();
      //Console.WriteLine("***********");
      //ExamScoresPlusNamePlusExamNameLookup();
      //Console.WriteLine("***********");
      //GroupExamScoresBySubject();
      //Console.WriteLine("***********");
      //GroupExamScoresBySubjectByGender();
      //Console.WriteLine("***********");
      //AveragesByAge();
      //Console.WriteLine("***********");
      //AverageMarkPerSubject();
      //Console.WriteLine("***********");
      //BestMarkPerSubjectPerGender();
      //Console.WriteLine("***********");
      //SubjectsWhereAverageMarkGt70();
      //Console.WriteLine("***********");
      //WhatIsCombinedDurationofAllExams();
      //Console.WriteLine("***********");
      //HowLongIsTheLongestStudentName();
      //Console.WriteLine("***********");
      //BasicJoin();
      //Console.WriteLine("***********");
      //GroupJoin();
      //Console.WriteLine("***********");
    }
    private static void ExamScores()
    {
      var examscores = from r in results
                       orderby r.ExamCode, r.Marks descending
                       select r;

      Console.WriteLine("\nHere are marks achieved by each student (name) in each subject (code) ");
      foreach (var item in examscores)
      {
        Console.WriteLine("{0} in {1} scored {2}", item.Initials, item.ExamCode, item.Marks);
      }
    }

    private static void ExamScoresPlusNameLookup()
    {
      var examscores = from r in results
                       join s in students
                       on r.Initials equals s.Initials
                       orderby r.ExamCode, s.Gender,  r.Marks 
                       select new { s.Name, r.ExamCode, r.Marks };

      Console.WriteLine("\nHere are marks achieved by each student (name) in each subject (code) ");
      foreach (var item in examscores)
      {
        Console.WriteLine("{0} in {1} scored {2}", item.Name, item.ExamCode, item.Marks);
      }
    }
    private static void ExamScoresPlusNamePlusExamNameLookup()
    {
      var query = from r in results
                  join s in students
                  on r.Initials equals s.Initials
                  join e in exams
                  on r.ExamCode equals e.ExamCode
                  orderby e.ExamCode, r.Marks descending
                  select new { s.Name, e.ExamName, r.Marks };

      Console.WriteLine("\nHere are marks achieved by each student(name) in each subject(name)");
      foreach (var item in query)
      {
        Console.WriteLine("{0} was scored by - {1} in {2}", item.Marks, item.Name, item.ExamName);
      }


    }

    private static void GroupExamScoresBySubject()
    {
      var query = from r in results
                  join s in students
                  on r.Initials equals s.Initials
                  join e in exams
                  on r.ExamCode equals e.ExamCode
                  orderby r.Marks descending
                  group new { s.Name, r.Marks, s.Gender } by e.ExamName;

      Console.WriteLine("\nHere are marks for each student by subject ");
      foreach (var exam in query)
      {
        Console.WriteLine("\nSubject - {0}", exam.Key);
        foreach (var item in exam)
        {
          Console.WriteLine("{0} was scored by - {1}({2})", item.Marks, item.Name, item.Gender);
        }
      }


    }
    private static void GroupExamScoresBySubjectByGender()
    {
      var query = from r in results
                  join s in students
                  on r.Initials equals s.Initials
                  join e in exams
                  on r.ExamCode equals e.ExamCode
                  orderby e.ExamCode, s.Gender descending
                  group new { s.Name, r.Marks } by new { e.ExamName, s.Gender };


      Console.WriteLine("\nHere are marks for each student by subject by gender ");
      foreach (var exam_gender in query)
      {
        Console.WriteLine("Subject {0} - {1}",
                            exam_gender.Key.ExamName,
                            exam_gender.Key.Gender == "F" ? "Girls" : "Boys");
        foreach (var item in exam_gender)
        {
          Console.WriteLine("{0} was scored by - {1}", item.Marks, item.Name);
        }
      }
    }

    private static void AveragesByAge()
    {
      Console.WriteLine();
      var ages = from s in students
                 select s.Age;

      var distinctages = ages.Distinct();

      //or
      var distinctages2 = (from s in students
                 select s.Age).Distinct();

      foreach (int age in distinctages)
      {
        var marksforAge = from r in results
                          join s in students
                          on r.Initials equals s.Initials
                          where s.Age == age
                          select r.Marks;
        Console.WriteLine("The average mark for students of age {0} is {1}", age, marksforAge.Average());
      }



    }

    private static void AverageMarkPerSubject()
    {
      Console.WriteLine();
      foreach (Exam exam in exams)
      {
        var marksForSubject = from r in results
                              where r.ExamCode == exam.ExamCode
                              select r.Marks;
        Console.WriteLine("Average mark in subject {0} is {1}", exam.ExamName, marksForSubject.Average());
      }
    }

    private static void BestMarkPerSubjectPerGender()
    {
      Console.WriteLine();
      var genders = from s in students
                    select s.Gender;
      var distinctGenders = genders.Distinct();
      foreach (Exam exam in exams)
      {

        foreach (String gender in distinctGenders)
        {
          var marksForSubject = from r in results
                                join s in students
                                    on r.Initials equals s.Initials
                                where r.ExamCode == exam.ExamCode && s.Gender == gender
                                select r.Marks;
          Console.WriteLine("Best mark in subject {0} for {1} is {2}",
                              exam.ExamName,
                              gender == "F" ? "girls" : "boys",
                              marksForSubject.Max()
                            );
        }
      }



    }

    private static void SubjectsWhereAverageMarkGt70()
    {
      Console.WriteLine();
      var aveGt70 = from r in results
                    group r.Marks by r.ExamCode into groupofMarks
                    where groupofMarks.Average() > 70
                    select groupofMarks;
      foreach (var exam in aveGt70)
      {
        Console.WriteLine(exam.Key + " is 1 of {0} subject(s) with average greater than 70", aveGt70.Count());
      }


    }

    private static void WhatIsCombinedDurationofAllExams()
    {
      var examdurations = from e in exams
                          select e.Duration;
      Console.WriteLine("\nCombined length of all the exams is {0} mins", examdurations.Sum());
    }

    private static void HowLongIsTheLongestStudentName()
    {
      var names = from s in students
                  select s.Name;
      
      int longestName = names.Max(s => s.Length);
      
      Console.WriteLine("\nThe length of the longest student name is {0} chars", longestName);

    }

    private static void BasicJoin()
    {
      string[] commonHobbies = { "Films", "Travel", "Surfing", "Sport", "Paleontology", "Shopping" };
      var matchedHobbies = from s in students
                           join h in commonHobbies
                           on s.Hobby equals h
                           orderby s.Hobby
                           select new { s.Name, s.Hobby };
      foreach (var person in matchedHobbies)
      {
        string name = person.Name;
        Console.WriteLine("{0} enjoys {1}", name.Substring(0, name.IndexOf(' ')), person.Hobby);
      }

    }

    private static void GroupJoin()
    {
      string[] commonHobbies = { "Films", "Travel", "Surfing", "Sport", "Paleontology", "Shopping" };
      var hobbyGroup = from h in commonHobbies
                       join s in students
                       on h equals s.Hobby into matches
                       select new { Hobby = h, Count = matches.Count() }
                         into summary
                         //where summary.Count > 0
                         orderby summary.Count descending
                         select summary;
      Console.WriteLine();
      foreach (var item in hobbyGroup)
      {
        Console.WriteLine("Hobby - '{0}' is enjoyed by {1} of the students", item.Hobby, item.Count);
      }

    }

  }
}

 
